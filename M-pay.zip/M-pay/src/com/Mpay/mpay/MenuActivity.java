package com.Mpay.mpay;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.view.View;
import android.content.Intent;

public class MenuActivity extends Activity implements View.OnClickListener {
	Button paybill;
	Button shoponline;
	Button receive;
	Button withdraw;
	Button mpesa;
	Button buygoods;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_menu);

		paybill = (Button) findViewById(R.id.paybill);
		paybill.setOnClickListener(this);

		shoponline = (Button) findViewById(R.id.shoponline);
		shoponline.setOnClickListener(this);

		receive = (Button) findViewById(R.id.receive);
		receive.setOnClickListener(this);

		withdraw = (Button) findViewById(R.id.withdraw);
		withdraw.setOnClickListener(this);

		paybill = (Button) findViewById(R.id.paybill);
		paybill.setOnClickListener(this);

		mpesa = (Button) findViewById(R.id.mpesa);
		mpesa.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// default method for handling onClick Events..
		startActivity(new Intent(MenuActivity.this, ScannedBarCodeActivity.class));
	}
}
