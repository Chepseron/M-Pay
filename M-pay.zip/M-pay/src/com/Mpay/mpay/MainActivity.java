package com.Mpay.mpay;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Properties;

import com.Mpay.model.Login;
import com.Mpay.model.PostRequests;
import com.Mpay.model.PropertyReader;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.content.Intent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
	Button signIn, signUp;
	EditText userName, et_password, et_repassword;
	Properties properties;
	PropertyReader propertyReader = new PropertyReader(this);
	String response;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		signIn = (Button) findViewById(R.id.btn_login);
		userName = (EditText) findViewById(R.id.et_email);
		et_password = (EditText) findViewById(R.id.et_password);
		et_repassword = (EditText) findViewById(R.id.et_repassword);

		signIn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// call the login api
				Login login = new Login();
				login.setEmail(userName.getText().toString());
				login.setPassword(et_password.getText().toString());
				PostRequests request = new PostRequests();
				try {
					response = request.postRequest(login, new URL(propertyReader.getMyProperties("project.properties").getProperty("url").toString()));
				} catch (MalformedURLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if (response.equals(000)) {
					startActivity(new Intent(MainActivity.this, MenuActivity.class));
				} else {
					Toast.makeText(getApplicationContext(), "Wrong Credentials", Toast.LENGTH_SHORT).show();

				}
			}
		});

		signUp.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				startActivity(new Intent(MainActivity.this, SignUpActivity.class));
			}
		});
	}
}
