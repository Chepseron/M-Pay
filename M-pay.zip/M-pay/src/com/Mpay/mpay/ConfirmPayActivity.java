package com.Mpay.mpay;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import javax.imageio.ImageIO;

import com.Mpay.model.PostRequests;
import com.Mpay.model.PropertyReader;
import com.Mpay.model.bank;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.NotFoundException;
import com.google.zxing.Result;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.common.HybridBinarizer;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ConfirmPayActivity extends Activity {
	Button confirmPay;
	EditText CreditQrCode;
	String DebitQrCode;
	EditText Amount;
	EditText Phone;
	EditText Bank;
	EditText Name;
	EditText Account;
	EditText Email;
	EditText Currency;
	EditText Commision;
	PropertyReader propertyReader = new PropertyReader(this);

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_confirm_pay);
		confirmPay = (Button) findViewById(R.id.confirmPay);
		try {
			CreditQrCode = (EditText) findViewById(R.id.QrCode);
			Amount = (EditText) findViewById(R.id.et_amount);
			Bank = (EditText) findViewById(R.id.et_bank_payment);
			Phone = (EditText) findViewById(R.id.et_phone_payment);
			Account = (EditText) findViewById(R.id.et_account_payment);
			Email = (EditText) findViewById(R.id.et_email_payment);
			Name = (EditText) findViewById(R.id.et_name_payment);
			Currency = (EditText) findViewById(R.id.et_currency);
			Commision = (EditText) findViewById(R.id.et_commision);

			if (getIntent().getStringExtra("QrCode") != null) {
				CreditQrCode.setText("Merchant Qr Code is : " + getIntent().getStringExtra("QrCode"));
				Bank.setText(getIntent().getStringExtra("QrCode").toString().split(":")[0]);
				Account.setText(getIntent().getStringExtra("QrCode").toString().split(":")[1]);
				Amount.setText(getIntent().getStringExtra("QrCode").toString().split(":")[2]);
				Phone.setText(getIntent().getStringExtra("QrCode").toString().split(":")[3]);
				Email.setText(getIntent().getStringExtra("QrCode").toString().split(":")[4]);
				Name.setText(getIntent().getStringExtra("QrCode").toString().split(":")[5]);
				Commision.setText(getIntent().getStringExtra("QrCode").toString().split(":")[6]);
				Currency.setText(getIntent().getStringExtra("QrCode").toString().split(":")[7]);
			}
			confirmPay.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					try {
					
						URL url;
						url = new URL(propertyReader.getMyProperties("project.properties").getProperty("url").toString());
						PostRequests postRequest = new PostRequests();
					
						// the path where the app owner QR code is saved
						String path = "code.png";
						String charset = "UTF-8";
						Map<EncodeHintType, ErrorCorrectionLevel> hintMap = new HashMap<EncodeHintType, ErrorCorrectionLevel>();
						hintMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);

						System.out.println("Customer or App Owner QR Code is: \n" + readQRcode(path, charset, hintMap));
						DebitQrCode = readQRcode(path, charset, hintMap);

						// make first call to Debit the app owners account
						// 1: pick the customer details for who scanned, select from the registration
						// table, pick based on phone number(unique Id
						// select bank name from drop down, and bank code, on the server pick table
						// denoted by bank code = on selecting select customer
						// details, pick the account and withdraw from the same.
						// customers bank
						bank BankDr = new bank();
						BankDr.setBank(DebitQrCode.split(":")[0]);
						BankDr.setAccount(DebitQrCode.split(":")[1]);
						BankDr.setAmount(new Float(DebitQrCode.split(":")[2]));
						BankDr.setPhone(DebitQrCode.split(":")[3]);
						BankDr.setEmail(DebitQrCode.split(":")[4]);
						BankDr.setName(DebitQrCode.split(":")[5]);
						BankDr.setCommision(Float.parseFloat(DebitQrCode.split(":")[6]));
						BankDr.setCurrency(DebitQrCode.split(":")[7]);
						BankDr.setDebit(true);
						Toast.makeText(getApplicationContext(), postRequest.postRequest(BankDr, url),
								Toast.LENGTH_SHORT).show();

						// make second call to credit the merchants account
						// 2: select the scanned barcode and decode from the code and pick details(we
						// can bundle up the QR using comma separated or ISO with | separated)
						// once details are obtained then proceed to select the bank and do the same
						// process as 1 above.
						// merchants bank
						bank BankCr = new bank();
						BankCr.setAccount(Account.getText().toString());
						BankCr.setBank(Bank.getText().toString());
						BankCr.setEmail(Email.getText().toString());
						BankCr.setName(Name.getText().toString());
						BankCr.setPhone(Phone.getText().toString());
						BankCr.setCommision(Float.parseFloat(Commision.getText().toString()));
						BankCr.setCurrency(Currency.getText().toString());
						BankCr.setDebit(false);
						Toast.makeText(getApplicationContext(), postRequest.postRequest(BankCr, url),
								Toast.LENGTH_SHORT).show();
					} catch (Exception ex) {
						Toast.makeText(getApplicationContext(), ex.getMessage(), TRIM_MEMORY_BACKGROUND);
					}
				}
			});

		} catch (Exception ex) {
			Toast.makeText(getApplicationContext(), ex.getMessage(), TRIM_MEMORY_BACKGROUND);
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.confirm_pay, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int id = item.getItemId();
		if (id == R.id.action_settings) {

			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	public static String readQRcode(String path, String charset, Map map)
			throws FileNotFoundException, IOException, NotFoundException {
		BinaryBitmap binaryBitmap = new BinaryBitmap(
				new HybridBinarizer(new BufferedImageLuminanceSource(ImageIO.read(new FileInputStream(path)))));
		Result rslt = new MultiFormatReader().decode(binaryBitmap);
		return rslt.getText();
	}
}
