package com.Mpay.mpay;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import android.widget.Spinner;
import com.Mpay.model.PostRequests;
import com.Mpay.model.PropertyReader;
import com.Mpay.model.signUp;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SignUpActivity extends Activity {
	Button signIn, signUp;
	EditText et_email, et_name, et_password, et_repassword, et_account, et_phone;
	Spinner et_bank;
	Properties properties;
	PropertyReader propertyReader = new PropertyReader(this);
	signUp signup = new signUp();
	String response;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_sign_up);
		try {

			et_email = (EditText) findViewById(R.id.et_email);
			et_name = (EditText) findViewById(R.id.et_name);
			et_password = (EditText) findViewById(R.id.et_password);
			et_repassword = (EditText) findViewById(R.id.et_repassword);
			et_account = (EditText) findViewById(R.id.et_account);
			et_phone = (EditText) findViewById(R.id.et_phone);

			// lets set the bank drop down
			properties = propertyReader.getMyProperties("project.properties");
			URL url = new URL(properties.getProperty("url").toString());
			PostRequests postRequest = new PostRequests();
			// lest assign the response of the array to banks after making a request to the
			// api to get the available banks
			// split the result which is comma separated and set to array
			String[] banks = postRequest.postRequest(signup, url).split(",");
			// pick the spinner and set the results
			Spinner bankSpinner = (Spinner) findViewById(R.id.et_bank);
			ArrayAdapter arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, banks);
			ArrayAdapter ad = arrayAdapter;
			ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			bankSpinner.setAdapter(ad);

			signup.setAccount(et_account.getText().toString());
			signup.setEmail(et_email.getText().toString());
			signup.setName(et_name.getText().toString());
			signup.setPassword(et_password.getText().toString());
			signup.setPhone(et_phone.getText().toString());
			signup.setBank(et_bank.getSelectedItem().toString());

			signUp = (Button) findViewById(R.id.btn_register);
			signUp.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {

					PostRequests postRequest = new PostRequests();
					if (response.equals(000)) {
						// celebrate
						URL url;
						try {
							url = new URL(properties.getProperty("url").toString());
							Toast.makeText(getApplicationContext(), postRequest.postRequest(signup, url),
									Toast.LENGTH_SHORT).show();
						} catch (MalformedURLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

						// display the customers QR code for payments

						// data that we want to store in the QR code
						String str = et_bank.getSelectedItem().toString() + ":" + et_account.getText().toString()
								+ ":0:" + et_phone.getText().toString() + ":" + et_email.getText().toString() + ":"
								+ et_name.getText().toString();

						// path where we want to get QR Code
						String path = "code.png";
						String charset = "UTF-8";
						Map<EncodeHintType, ErrorCorrectionLevel> hashMap = new HashMap<EncodeHintType, ErrorCorrectionLevel>();
						hashMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);
						generateQRcode(str, path, charset, hashMap, 200, 200);
						// prints if the QR code is generated
						Toast.makeText(getApplicationContext(), "Congratulations: you have successfully generated your QR code", Toast.LENGTH_SHORT);
					} else {
						Toast.makeText(getApplicationContext(),
								"An error occured during registration, check details and try again later",
								Toast.LENGTH_SHORT).show();
					}

				}
			});

		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.sign_up, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	public static void generateQRcode(String data, String path, String charset, Map map, int h, int w) {
		try {
			BitMatrix matrix = new MultiFormatWriter().encode(new String(data.getBytes(charset), charset),
					BarcodeFormat.QR_CODE, w, h);
			MatrixToImageWriter.writeToFile(matrix, path.substring(path.lastIndexOf('.') + 1), new File(path));
		} catch (Exception ex) {

		}
	}

}
