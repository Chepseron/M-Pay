package com.Mpay.model;

public class bank {
	private boolean Debit;
	private String name;
	private Float amount;
	private String email;
	private String password;
	private String bank;
	private String account;
	private String phone;
	private Float Commision;
	private String Currency;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getBank() {
		return bank;
	}

	public void setBank(String bank) {
		this.bank = bank;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	
	public Float getAmount() {
		return amount;
	}

	public void setAmount(Float amount) {
		this.amount = amount;
	}

	public boolean isDebit() {
		return Debit;
	}

	public void setDebit(boolean debit) {
		Debit = debit;
	}

	public Float getCommision() {
		return Commision;
	}

	public void setCommision(Float commision) {
		Commision = commision;
	}

	public String getCurrency() {
		return Currency;
	}

	public void setCurrency(String currency) {
		Currency = currency;
	}

	
	
	
}
