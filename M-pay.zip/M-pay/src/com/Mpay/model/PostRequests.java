
package com.Mpay.model;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import com.google.gson.Gson;

public class PostRequests {
//for bank calls, host a file(app.properties) containing bank name and API url
//separate DR CR requests with flags indicating you need an extra url to fetch the banks endpoint and make a call
	public String postRequest(Object object, URL url) {
		try {
			String response = null;
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			OutputStream os = conn.getOutputStream();
			os.write(new Gson().toJson(object).toString().getBytes());
			os.flush();
			if (conn.getResponseCode() != HttpURLConnection.HTTP_CREATED) {
				throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
			}
			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
			String output;
			System.out.println("Output from Server .... \n");
			while ((output = br.readLine()) != null) {
				System.out.println(output);
				response = output;
			}
			conn.disconnect();
			return response.toString();
		} catch (Exception ex) {

		}
		return null;
	}

}
